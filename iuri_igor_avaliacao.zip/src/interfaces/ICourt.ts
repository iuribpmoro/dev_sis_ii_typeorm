interface ICourt {
    id?: number;
    name: string;
    type: string;
}

export default ICourt;