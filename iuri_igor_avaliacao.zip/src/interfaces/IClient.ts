interface IClient {
  cpf: string;
  name: string;
  phone: string;
}
  
export default IClient;